from django.contrib import admin
from .modals.product import Product
from .modals.category import Category
from .modals.customer import Customer

class AdminProduct(admin.ModelAdmin):
    list_display = ['name' , 'price','category']
# Register your models here.

class AdminCategory(admin.ModelAdmin):
    list_display = ['name' ]



admin.site.register(Product , AdminProduct)
admin.site.register(Category,AdminCategory)
admin.site.register(Customer)